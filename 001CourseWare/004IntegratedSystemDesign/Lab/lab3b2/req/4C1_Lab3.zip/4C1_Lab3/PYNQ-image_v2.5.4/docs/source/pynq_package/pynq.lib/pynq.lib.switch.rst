.. _pynq-lib-switch:

pynq.lib.switch Module
======================

The pynq.lib.switch module is a driver for reading, and waiting for value
changes on onboard switches.

.. automodule:: pynq.lib.switch
    :members:
    :undoc-members:
    :show-inheritance:
