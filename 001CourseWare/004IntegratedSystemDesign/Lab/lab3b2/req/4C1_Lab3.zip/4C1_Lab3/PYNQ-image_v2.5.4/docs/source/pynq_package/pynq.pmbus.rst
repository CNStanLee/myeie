.. _pynq-pmbus:
   
pynq.pmbus Module
=================

.. automodule:: pynq.pmbus
    :members:
    :undoc-members:
    :show-inheritance:
