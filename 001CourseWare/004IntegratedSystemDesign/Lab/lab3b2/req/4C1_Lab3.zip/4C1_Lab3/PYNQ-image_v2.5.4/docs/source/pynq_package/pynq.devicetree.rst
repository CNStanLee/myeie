.. _pynq-devicetree:

pynq.devicetree Module
======================

The pynq.devicetree module enables users to insert or remove a device tree
segment. This can happen when users load a full/partial bitstream.

.. automodule:: pynq.devicetree
    :members:
    :undoc-members:
    :show-inheritance:
