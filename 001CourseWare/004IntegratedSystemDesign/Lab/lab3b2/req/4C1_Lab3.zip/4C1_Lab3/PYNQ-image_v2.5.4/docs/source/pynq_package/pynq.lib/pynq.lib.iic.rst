.. _pynq-lib-iic:

pynq.lib.iic Module
===================

The pynq.lib.iic module is a driver for interacting with the Xilinx Axi IIC
IP Block.

.. automodule:: pynq.lib.iic
    :members:
    :undoc-members:
    :show-inheritance:
