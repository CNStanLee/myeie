.. _pynq-buffer:

pynq.buffer Module
==================

Home of the ``pynq.allocate`` function

.. automodule:: pynq.buffer
    :members:
    :undoc-members:
    :show-inheritance:
