.. _pynq-lib-audio:

pynq.lib.audio Module
=====================

The pynq.lib.audio module is a driver for reading and recording values from an
on-board audio mirophone, loading preexisting audio files, or playing audio
input to an output device.

.. automodule:: pynq.lib.audio
    :members:
    :undoc-members:
    :show-inheritance:
