.. _pynq-pl_server-xclbin_parser:

pynq.pl_server.xclbin_parser Module
===================================

The pynq.pl_server.xclbin_parser module parses the metadata file from
the xclbin file. It extracts useful information about the system such as
the memory ports. 

.. automodule:: pynq.pl_server.xclbin_parser
    :members:
    :undoc-members:
    :show-inheritance:
