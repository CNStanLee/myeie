.. _pynq-pl_server-xrt_device:

pynq.pl_server.xrt_device Module
================================

The pynq.pl_server.xrt_device module extends the device class to work with
Xilinx Run Time (XRT) enabled devices.

.. automodule:: pynq.pl_server.xrt_device
    :members:
    :undoc-members:
    :show-inheritance:
