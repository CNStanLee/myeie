.. _pynq-lib-rpi:

pynq.lib.rpi Package
====================

The pynq.lib.rpi package is a collection of drivers for controlling peripherals
attached to a RPi interface. The RPi interface can control Raspberry Pi
peripherals.

pynq.lib.rpi Module
--------------------------------

.. automodule:: pynq.lib.rpi.rpi
    :members:
    :undoc-members:
    :show-inheritance:
