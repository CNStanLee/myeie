.. _pynq-lib-dma:

pynq.lib.dma Module
===================

.. automodule:: pynq.lib.dma
    :members:
    :undoc-members:
    :show-inheritance:
