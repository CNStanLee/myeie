pynq.lib.wifi Module
====================

The pynq.lib.wifi module is a python module for interacting with WiFI adapters. 
This module can be used to connect and disconnect to wireless networks.

.. automodule:: pynq.lib.wifi
    :members:
    :undoc-members:
    :show-inheritance:
