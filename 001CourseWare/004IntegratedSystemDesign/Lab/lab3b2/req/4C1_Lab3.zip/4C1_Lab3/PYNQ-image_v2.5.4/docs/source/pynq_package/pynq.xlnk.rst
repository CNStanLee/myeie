.. _pynq-xlnk:

pynq.xlnk Module
================

This module is now deprecated in favour of ``pynq.allocate``

.. automodule:: pynq.xlnk
    :members:
    :undoc-members:
    :show-inheritance:
