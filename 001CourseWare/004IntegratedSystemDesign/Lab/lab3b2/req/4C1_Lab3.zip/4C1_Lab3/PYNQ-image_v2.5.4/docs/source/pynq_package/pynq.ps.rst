.. _pynq-ps:

pynq.ps Module
==============

The pynq.ps module facilitates management of the Processing System (PS) and
PS/PL interface. It provides Clocks classes for setting and getting
of Programmable Logic (PL) clocks.

.. automodule:: pynq.ps
    :members:
    :undoc-members:
    :show-inheritance:
